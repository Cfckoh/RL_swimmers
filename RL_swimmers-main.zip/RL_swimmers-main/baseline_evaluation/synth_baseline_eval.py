import csv
import numpy as np
import sdeint
import yaml
import sys


def f(u, t):
    #print(u)
    return np.array([
        u[2]*u[0] + u[3]*u[1] - PHI * u[0],
        u[4]*u[0] + u[5]*u[1] - PHI * u[1],
        -u[2],
        -u[3],
        -u[4],
        -u[5]
    ])

def g(u, t):
    return np.array([
        [np.sqrt(kappa), 0, 0, 0, 0],
        [0, np.sqrt(kappa), 0, 0, 0],
        [0, 0, np.sqrt(D), 0, 0],
        [0, 0, 0, np.sqrt(D), np.sqrt(2) * np.sqrt(D)],
        [0, 0, 0, np.sqrt(D), -np.sqrt(2) * np.sqrt(D)],
        [0, 0, -np.sqrt(D), 0, 0]
    ])

def penalty(sep,phi,beta,delta_t):
    return (phi**2+beta)*sep**2*delta_t



if __name__=="__main__":
    
    # read config file passed in commandline
    config_file = f"{sys.argv[1]}"

    with open(f"baseline_config_files/{config_file}.yaml") as cf_file:
        config = yaml.safe_load( cf_file.read() )

    # load params from file
    dims=2 #2d batchelor flow
    
    NU = config["NU"] 
    kappa = config["kappa"] 
    BETA = config["BETA"]
    PHI = config["PHI"]
    D = config["D"]
    delta_t = config["delta_t"]
    delta_r = config["delta_r"]
    t_end = config["t_end"]
    num_eps = config["num_eps"]


    results_dict = {}

    u0 = np.random.rand(6)-0.5
    for i in range(num_eps):


        tspan = np.arange(0.0, t_end,delta_t)  # 10 time units

        result = sdeint.itoint(f, g, u0, tspan)
        
        # storing last value for the random start of the next episode
        u0 = result[-1]

        sep_vecs = result[:,0:2]
        separations = np.sum(sep_vecs**2,axis=1)
        separations = np.sqrt(separations)


        N = len(separations)
        S_n = 0.0
        returns = np.zeros(N)
        discount = np.exp(-NU*delta_t)
        for i in range(1,N+1):
            S_n = S_n*discount + penalty(separations[N-i],PHI,BETA,delta_t)
            returns[N-i] = S_n
            
        
        for i in range(N):
            key = (i, int(separations[i]/delta_r))
            if key in results_dict:
                # increase sum and count
                results_dict[key] = results_dict[key][0] + returns[i], results_dict[key][1] + 1
            else:
                results_dict[key] = [returns[i], 1]




    with open(f'baseline_CSVs/{config_file}.csv', 'w') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=list(results_dict.keys()))
        writer.writeheader()
        writer.writerow(results_dict)